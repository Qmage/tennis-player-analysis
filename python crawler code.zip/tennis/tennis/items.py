# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# http://doc.scrapy.org/en/latest/topics/items.html

import scrapy

class TennisPlayerItem(scrapy.Item):
    current_rank = scrapy.Field()
    previous_rank = scrapy.Field()
    name = scrapy.Field()
    country = scrapy.Field()
    date_of_birth = scrapy.Field()
    points = scrapy.Field()
    tournaments = scrapy.Field()
    url = scrapy.Field()
    height = scrapy.Field()
    weight = scrapy.Field()
    birthplace = scrapy.Field()
    plays = scrapy.Field()
    residence = scrapy.Field()