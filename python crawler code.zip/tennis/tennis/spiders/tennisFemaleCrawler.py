import scrapy
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from tennisfemale.items import TennisPlayerItem
import urlparse
import re

class tennisFemaleSpider(CrawlSpider):
    name = 'tennisFemaleSpider'
    allowed_domains = ['www.wtatennis.com']
    
    urls = []
    temp_url = "http://www.wtatennis.com/fragment/wtaTennis/fragments/assets/rankings/rankingsData/type/SINGLES/date/26042016/pag/{}01"
    for i in range(0, 20):
        urls.append(temp_url.format(i))
        
    start_urls = urls

    """
    rules = (
        # Extract links matching 'category.php' (but not matching 'subsection.php')
        # and follow links from them (since no callback means follow=True by default).
        Rule(LinkExtractor(allow=('category\.php', ))),

        # Extract links matching 'item.php' and parse them with the spider's method parse_item
        Rule(LinkExtractor(allow=('item\.php', )), callback='parse_item'),
    )
    """

    def parse_start_url(self, response):
        self.logger.info('Hi, this is a listing page! %s', response.url)
        
        player_urls = response.xpath("//table[@id='myTable']//td[3]/a/@href").extract()
        player_urls = [urlparse.urljoin('http://www.wtatennis.com/', x) for x in player_urls]

        previous_ranks = response.xpath("//table[@id='myTable']//td[1]//text()[2]").extract()
        previous_ranks = [x.strip().replace("[","").replace("]","") for x in previous_ranks]

        current_ranks = response.xpath("//table[@id='myTable']//td[2]//text()").extract()
        current_ranks = [x.strip() for x in current_ranks]

        player_names = response.xpath("//table[@id='myTable']//td[3]//text()").extract()
        player_names = [x.strip() for x in player_names]

        countries = response.xpath("//table[@id='myTable']//td[@class='mobile-center']/span[@class='mobile-show']/text()").extract()
        countries = [x.strip() for x in countries]

        date_of_births = response.xpath("//table[@id='myTable']//tr/td[@class='mobile-hide']/text()").extract()
        date_of_births = [x.strip() for x in date_of_births]

        points = response.xpath("//table[@id='myTable']//td[6]//text()").extract()
        points = [x.strip() for x in points]

        tournaments = response.xpath("//table[@id='myTable']//td[7]//text()").extract()
        tournaments = [x.strip() for x in tournaments]

        players_info = zip(player_urls, previous_ranks, current_ranks, player_names, countries, date_of_births, points, tournaments)
        keys = ["url", "previous_rank", "current_rank", "name", "country", "date_of_birth", "points", "tournaments"]
        players_info = [dict(zip(keys,x)) for x in players_info]
        
        for i in players_info:
            request = scrapy.Request(i['url'], callback=self.parse_player)
            request.meta['item'] = i
            yield request
    
    def parse_player(self, response):
        self.logger.info('Hi, this is player page! %s', response.url)
        
        item = response.meta['item']
        
        height = response.xpath("//div[@class='player-bio clearfix']//li[4]/text()").re('\((.*) m\)')
        item['height'] = ""
        if len(height)> 0:
            item['height'] = height[0]
            
        weight = response.xpath("//div[@class='player-bio clearfix']//li[5]/text()").re(': (.*) lbs')
        item['weight'] = ""
        if len(weight) >0:
            item['weight'] = weight[0]
            
        birthplace = response.xpath("//div[@class='player-bio clearfix']//li[3]/text()").extract()
        item['birthplace'] = ""
        if len(birthplace) >0:
            item['birthplace'] = birthplace[0].replace(":","").strip()
            
        plays = response.xpath("//div[@class='player-bio clearfix']//li[6]/text()").extract()
        item['plays'] = ""
        if len(plays) >0:
            item['plays'] = plays[0].replace(":","").strip()
            
        residence = response.xpath("//div[@class='player-bio clearfix']//li[1]/text()").extract()
        item['residence'] = ""
        if len(residence) >0:
            item['residence'] = residence[0].replace(":","").strip()
        
        playerItem = TennisPlayerItem()
        for k in item:
            playerItem[k] = item[k]
        
        return playerItem