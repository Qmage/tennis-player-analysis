import scrapy
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from tennisfemale.items import TennisPlayerItem
import urlparse
import re

class tennisMaleSpider(CrawlSpider):
    name = 'tennisMaleSpider'
    allowed_domains = ['www.atpworldtour.com']
    start_urls = ['http://www.atpworldtour.com/en/rankings/singles?rankDate=2016-04-25&rankRange=1-2000']

    """
    rules = (
        # Extract links matching 'category.php' (but not matching 'subsection.php')
        # and follow links from them (since no callback means follow=True by default).
        Rule(LinkExtractor(allow=('category\.php', ))),

        # Extract links matching 'item.php' and parse them with the spider's method parse_item
        Rule(LinkExtractor(allow=('item\.php', )), callback='parse_item'),
    )
    """

    def parse_start_url(self, response):
        self.logger.info('Hi, this is a listing page! %s', response.url)
        
        player_urls = response.xpath("//td[@class='player-cell']/a/@href").extract()
        player_urls = [urlparse.urljoin('http://www.atpworldtour.com/', x) for x in player_urls]

        current_ranks = response.xpath("//td[@class='rank-cell']/text()").extract()
        current_ranks = [x.strip().replace("T","") for x in current_ranks]
        
        move_ranks = response.xpath("//td[@class='move-cell']/div[@class='move-text']/text()").extract()
        move_ranks = [x.strip() for x in move_ranks]
        move_direction = response.xpath("//td[@class='move-cell']/div[@class!='move-text']/@class").extract()
        movement = zip(current_ranks, move_ranks, move_direction)
        previous_ranks = []
        for m in movement:
            prev = ""
            if m[2] == 'move-none':
                prev = m[0]
            elif m[2] == 'move-up':
                prev = str(int(m[0]) + int(m[1]))
            elif m[2] == 'move-down':
                prev = str(int(m[0]) - int(m[1]))
                
            previous_ranks.append(prev)

        player_names = response.xpath("//td[@class='player-cell']/a/text()").extract()

        countries = response.xpath("//td[@class='country-cell']//@alt").extract()

        points = response.xpath("//td[@class='points-cell']/a/text()").extract()
        points = [x.replace(",","") for x in points]

        tournaments = response.xpath("//td[@class='tourn-cell']/a/text()").extract()

        players_info = zip(player_urls, previous_ranks, current_ranks, player_names, countries, points, tournaments)
        keys = ["url", "previous_rank", "current_rank", "name", "country", "points", "tournaments"]
        players_info = [dict(zip(keys,x)) for x in players_info]
        
        for i in players_info:
            request = scrapy.Request(i['url'], callback=self.parse_player)
            request.meta['item'] = i
            yield request
    
    def parse_player(self, response):
        self.logger.info('Hi, this is player page! %s', response.url)
        
        item = response.meta['item']
        
        date_of_birth = response.xpath("//span[@class='table-birthday']/text()").extract()
        item['date_of_birth'] = ""
        if len(date_of_birth)> 0:
            item['date_of_birth'] = date_of_birth[0].strip().replace("(","").replace(")","")
        
        height = response.xpath("//span[@class='table-height-cm-wrapper']/text()").extract()
        item['height'] = ""
        if len(height)> 0:
            item['height'] = height[0].replace("(","").replace(")","").replace("cm","")
            
        weight = response.xpath("//span[@class='table-weight-lbs']/text()").extract()
        item['weight'] = ""
        if len(weight) >0:
            item['weight'] = weight[0]
        
        birthplace_residence_plays = response.xpath("//div[@class='table-value']/text()").extract()
        item['birthplace'] = ""
        item['residence'] = ""
        item['plays'] = ""
        if len(birthplace_residence_plays) > 2:
            birthplace = response.xpath("//div[@class='table-value']/text()").extract()[0]
            residence = response.xpath("//div[@class='table-value']/text()").extract()[1]
            plays = response.xpath("//div[@class='table-value']/text()").extract()[2]
            item['birthplace'] = birthplace.strip()
            item['residence'] = residence.strip()
            item['plays'] = plays.strip()
            
        playerItem = TennisPlayerItem()
        for k in item:
            playerItem[k] = item[k]
        
        return playerItem